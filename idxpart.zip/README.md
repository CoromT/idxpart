# idxpart
Easily manage partitioned Azure Search Indexers to sync large quantities of data.
